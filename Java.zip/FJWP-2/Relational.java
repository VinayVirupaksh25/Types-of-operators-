package vinay;

public class Relational {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 10;
        int y = 20;

        System.out.println(x < y); // true
        System.out.println(x > y); // false
        System.out.println(x <= y); // true
        System.out.println(x >= y); // false
        System.out.println(x == y); // false
        System.out.println(x != y); // true
	}

}
